package com.riyaltrack.app

import android.content.ContentValues
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import androidx.room.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amountMinor: Long,
    val currency: String = "SAR",
    val bankMerchant: String = "",
    val actualMerchant: String = "",
    val category: String = "Other",
    val note: String = "",
    val receiptUri: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val confirmed: Boolean = false
)

@Dao
interface ExpenseDao {
    @Query("SELECT * FROM expenses ORDER BY createdAt DESC")
    suspend fun all(): List<Expense>

    @Insert
    suspend fun insert(expense: Expense): Long

    @Update
    suspend fun update(expense: Expense)

    @Query("SELECT COALESCE(SUM(amountMinor), 0) FROM expenses WHERE createdAt >= :from AND createdAt < :until")
    suspend fun totalBetween(from: Long, until: Long): Long
}

@Database(entities = [Expense::class], version = 1, exportSchema = false)
abstract class ExpenseDatabase : RoomDatabase() {
    abstract fun expenseDao(): ExpenseDao
    companion object {
        @Volatile private var INSTANCE: ExpenseDatabase? = null
        fun get(context: android.content.Context): ExpenseDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext, ExpenseDatabase::class.java, "riyaltrack.db"
                ).build().also { INSTANCE = it }
            }
    }
}

class MainActivity : ComponentActivity() {
    private val db by lazy { ExpenseDatabase.get(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                ExpenseScreen(
                    onSave = { amount, category, merchant, bankMerchant, note, receipt ->
                        lifecycleScope.launch {
                            db.expenseDao().insert(
                                Expense(
                                    amountMinor = (amount.toDoubleOrNull()?.times(100))?.toLong() ?: 0,
                                    category = category,
                                    actualMerchant = merchant,
                                    bankMerchant = bankMerchant,
                                    note = note,
                                    receiptUri = receipt,
                                    confirmed = true
                                )
                            )
                        }
                    },
                    loadExpenses = { db.expenseDao().all() }
                )
            }
        }
    }
}

@Composable
fun ExpenseScreen(
    onSave: (String, String, String, String, String, String?) -> Unit,
    loadExpenses: suspend () -> List<Expense>
) {
    var amount by remember { mutableStateOf("47.00") }
    var category by remember { mutableStateOf("Other") }
    var merchant by remember { mutableStateOf("Local grocery shop") }
    var bankMerchant by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var receiptUri by remember { mutableStateOf<String?>(null) }
    var savedMessage by remember { mutableStateOf("") }
    var expenses by remember { mutableStateOf<List<Expense>>(emptyList()) }
    var showCategoryMenu by remember { mutableStateOf(false) }

    val pickReceipt = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? -> receiptUri = uri?.toString() }

    LaunchedEffect(Unit) { expenses = loadExpenses() }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("RiyalTrack", style = MaterialTheme.typography.headlineMedium)
        Text("Private expense log · stored on this device")
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("New expense", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(
                    value = amount, onValueChange = { amount = it },
                    label = { Text("Amount (SAR)") }, singleLine = true
                )
                OutlinedTextField(
                    value = bankMerchant, onValueChange = { bankMerchant = it },
                    label = { Text("Bank merchant description") }, singleLine = true
                )
                OutlinedTextField(
                    value = merchant, onValueChange = { merchant = it },
                    label = { Text("Actual shop / merchant") }, singleLine = true
                )
                Box {
                    OutlinedButton(onClick = { showCategoryMenu = true }) {
                        Text("Category: $category")
                    }
                    DropdownMenu(
                        expanded = showCategoryMenu,
                        onDismissRequest = { showCategoryMenu = false }
                    ) {
                        listOf("Groceries", "Restaurant / Food", "Transport / Fuel",
                            "Shopping", "Bills", "Family / India", "Medical", "Other").forEach {
                            DropdownMenuItem(
                                text = { Text(it) },
                                onClick = { category = it; showCategoryMenu = false }
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = note, onValueChange = { note = it },
                    label = { Text("Note (optional)") }
                )
                OutlinedButton(onClick = { pickReceipt.launch("image/*") }) {
                    Text(if (receiptUri == null) "Choose bill photo" else "Receipt attached ✓")
                }
                Text(
                    if (receiptUri == null) "No receipt selected" else "Selected: ${Uri.parse(receiptUri).lastPathSegment ?: "image"}",
                    style = MaterialTheme.typography.bodySmall
                )
                Button(onClick = {
                    val parsed = amount.toDoubleOrNull()
                    if (parsed == null || parsed <= 0) {
                        savedMessage = "Enter a valid amount."
                    } else {
                        onSave(amount, category, merchant, bankMerchant, note, receiptUri)
                        savedMessage = "Expense saved on this device."
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Save expense") }
                if (savedMessage.isNotBlank()) Text(savedMessage)
            }
        }
        Text("Recent expenses", style = MaterialTheme.typography.titleLarge)
        expenses.forEach { e ->
            Card {
                Column(Modifier.padding(12.dp)) {
                    Text("${e.amountMinor / 100.0} ${e.currency}", style = MaterialTheme.typography.titleMedium)
                    Text("${e.category} · ${e.actualMerchant}")
                    if (e.bankMerchant.isNotBlank()) Text("Bank: ${e.bankMerchant}")
                    Text(if (e.receiptUri == null) "Receipt missing" else "Receipt attached")
                    Text(SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(e.createdAt)))
                }
            }
        }
    }
}
