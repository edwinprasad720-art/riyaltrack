# RiyalTrack — Android starter project

A privacy-first starter app for manually confirming expenses, categorizing them, adding the real merchant name, attaching a receipt image, and storing records in a local Room database.

## Current features
- Kotlin + Jetpack Compose Android app.
- Local Room database for persistent expense records.
- Example prefilled transaction: 47.00 SAR, category Other, actual merchant Local grocery shop.
- Image picker for bill photos.
- Separate bank merchant description and actual merchant fields.
- Recent expense list.

## Important limitations in this starter
- This is source code, not an installed APK. Build it in Android Studio.
- Transaction detection from bank SMS or notifications is **not implemented yet**. It must be added separately and tested against the exact bank messages/notification format.
- The selected receipt URI is stored in the database, but this starter uses the system picker URI directly. For robust long-term access, implement a persistable URI permission flow or copy the selected image into app-private storage before saving.
- The save callback is asynchronous; the screen's current recent list refreshes on first launch only. A production version should use Flow/StateFlow so the list updates immediately.
- No cloud sync, analytics, ads, or bank login are included.
- The amount field currently accepts a decimal string and stores it as minor units; production code should use a locale-safe currency parser.

## Build
1. Install Android Studio and a compatible JDK 17.
2. Open this folder in Android Studio.
3. Allow Gradle sync to download dependencies.
4. Run on an Android device or emulator.

## Suggested next implementation phases
1. Replace receipt picker with `PickVisualMedia` and copy the image to app-private storage.
2. Use Room `Flow` for live transaction lists and monthly reports.
3. Add notification listener service as an optional, user-enabled feature to parse supported bank transaction notifications. Android requires the user to explicitly grant Notification Access in Settings. This will not see every SMS or every bank transaction.
4. If SMS reading is considered, implement only with explicit user consent and review Google Play's sensitive-permission policy before distribution. Avoid broad SMS permissions unless absolutely necessary.
5. Add duplicate detection, pending reminders, salary income, transfers/remittances, CSV export, app lock, and encrypted export/backup.
6. Add tests using anonymized sample messages from the user's own bank.

## Privacy notes
The app does not currently request SMS, notification-listener, contacts, or internet permissions. Receipt images are selected through Android's system picker. Do not add bank credentials, PINs, or OTP collection.
